export const LoadingQuote = () => {
  return (
    <div className="alert alert-info text-center">
        Loading...
    </div>
  )
}